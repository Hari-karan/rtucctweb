<?php
include("db.php");
$name=$_POST['name'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$title=$_POST['title'];
$category=$_POST['category'];
$designation=$_POST['designation'];
$department=$_POST['department'];
$accomodation=$_POST['accomodation'];
$address=$_POST['address'];
$amount=$_POST['amount'];
$ddno=$_POST['ddno'];
$bank=$_POST['bank'];


$sql="INSERT INTO `rtucct`.`register` (`id`,`name`, `email`,`phone`, `title`, `category`, `designation`, `department`, `accomodation`, `address`, `amount`, `ddno`, `bank`) VALUES (NULL,'$name', '$email', '$phone','$title', '$category', '$designation', '$department', '$accomodation', '$address', '$amount', '$ddno', '$bank')";
if(mysqli_query($con,$sql))
{
	echo"success";
}
else
{
	echo"Data Error!";
}
header("Location:../index.html");
?>