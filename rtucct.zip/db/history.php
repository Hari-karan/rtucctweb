

<html lang="en">
<head>
  	<meta charset="UTF-8">
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="icon" type="image/png" href="../images/bitlogo.png" sizes="32x32">
	   <script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
    
	<title>Registration Details</title>
</head>
    
        
   
<style>
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #27bed6;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #dddddd;
}
@media 
only screen and (max-width: 1200px),
(min-device-width: 768px) and (max-device-width: 1024px)  {


	table, thead, tbody, th, td, tr { 
		display: block; 
	}
	

	thead tr { 
		position: absolute;
		top: -9999px;
		left: -9999px;
	}
	
	tr { border: 1px solid #ccc; }
	
	td { 
	font-size:40px;
		border: none;
		border-bottom: 1px solid #eee; 
		position: relative;
		padding-left: 40%; 
	}
	.form-control
	{
		font-size:20px;
	}
	.btn{
		font-size:30px;
	}
	
	td:before { 
		
		position: absolute;
	
		top: 6px;
		left: 6px;
		width: 45%; 
		padding-right: 10px; 
		white-space: nowrap;
	}
	
	
	td:nth-of-type(1):before { content: " Name"; }
	td:nth-of-type(2):before { content: "email address"; }
	td:nth-of-type(3):before { content: "phone number"; }	
	td:nth-of-type(4):before { content: "Title of the paper"; }
	td:nth-of-type(5):before { content: "Registration Category"; }
	td:nth-of-type(6):before { content: "Designation:"; }	
	td:nth-of-type(7):before { content: "Department"; }
	td:nth-of-type(8):before { content: "Accommodation"; }
	td:nth-of-type(9):before { content: "Address :"; }
    td:nth-of-type(10):before { content: "Amount"; }
	td:nth-of-type(11):before { content: "DD No."; }	
    td:nth-of-type(12):before { content: "	Issuing Bank"; }
    td:nth-of-type(13):before { content: "Date"; }
    td:nth-of-type(14):before { content: "ID"; }
}


.table1{
	margin-top:2%;
}
</style>
<body>
<?php
include("db.php");
$date=date('Y-m-d');
?>
 <header class="subhead" id="overview">
      <div class="container">
          
        <h1>Registration Details</h1>
        
      </div>
     <p>Click here to search:</p>  
<input id="myInput" type="text" placeholder="Search.." >
<br><br>
     
    </header>
   
<button type="button" class="btn btn-success" onclick="my_count()">COUNT</button>
	 <table class="table1" id="mytable">
    <thead>
      <tr>
        <th>Name</th>
        <th>email address</th>
        <th>phone number</th>
		<th>Title of the paper</th>
		<th>Registration Category</th>
          <th>Designation</th>
		<th>Department</th>
          <th>Accommodation</th>
		<th>Address</th>
          <th>Amount</th>
		<th>DD No.</th>
          <th>Issuing Bank:</th>
		
		<th>Date|Time</th>
		<th>ID</th>
		
      </tr>
    </thead>
    <tbody>
<?php
        $count=0;
$sql="SELECT `id`,`name`, `email`, `phone`, `title`, `category`, `designation`,`department`,`accomodation`,`address`,`amount`,`ddno`,`bank`,`date` FROM `rtucct`.`register` WHERE 1";
$result=$con->query($sql);
		   if($result->num_rows>0)
		   {
			   while($row = $result->fetch_assoc())
			   {
                   ++$count;
?>                       
      <tr>
        <td><?php echo $row['name']; ?></td>
         <td><?php echo $row['email']; ?></td>
          <td><?php echo $row['phone']; ?></td>
		   <td><?php echo $row['title']; ?></td>
		    <td><?php echo $row['category']; ?></td>
		     <td><?php echo $row['designation']; ?></td>
			  <td><?php echo $row['department']; ?></td>
			   <td><?php echo $row['accomodation']; ?></td>
			    <td><?php echo $row['address']; ?></td>
                 <td><?php echo $row['amount']; ?></td>
                  <td><?php echo $row['ddno']; ?></td>
                   <td><?php echo $row['bank']; ?></td>
                    
                     <td><?php echo $row['date']; ?></td>
                      <td><?php echo $row['id']; ?></td>
			   
      </tr>
<?php
		 
               }}
?>     
    
    </tbody>
  </table>
    <label>
    TOTAL COUNT:
    
    </label><input type=text readonly placeholder="<?php echo $count ?>">
    <script>
        var count="<?php echo $count ?>";
    function my_count()
    {
        alert("COUNT IS  --> "+count);
    }
        $(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
    
    </script>
</body>
